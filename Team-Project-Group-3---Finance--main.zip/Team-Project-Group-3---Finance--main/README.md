# Team-Project-Group-3---Finance-

## Project Title: US Supermarket Stock and Investment Analysis

**Group Members:** Alex, Murali, Eleanor, Devon, Archie, Vavara, Zainab, Ayesha

This GitHub repository holds all the relvant fiels for this project. The **'presentation'** folder holds the project proposal, slide presentation and the final analysis report.  The **'output'** folder holds some of the key charts from the jupyter notebook code. The python code generating the ouput charts is stored in the **'code'** folder. We do have an **'archive'** folder for any files used for experimental code during the project. The 'data' folder holds data source for call the code block. All of the data files in the data folder is sourced from Yahoo Finance and saved as .CSV files.